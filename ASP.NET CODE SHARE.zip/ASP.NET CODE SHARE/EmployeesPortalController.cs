﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EFCoreRepositoryPatternDemo.Models;

namespace EFCoreRepositoryPatternDemo.Controllers
{
    public class EmployeesPortalController : Controller
    {
        //private readonly AppDBContext _context;
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeesPortalController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        // GET: EmployeesPortal
        public IActionResult Index()
        {
            return View(_employeeRepository.GetAllEmployee());
        }

        // GET: EmployeesPortal/Details/5
        // GET: Employees/Details/5
        public IActionResult Details(int id)
        {
            if (id < 0)
            {
                return NotFound();
            }
            var clsEmployee = _employeeRepository.GetEmployeeByID(id);


            if (clsEmployee == null)
            {
                return NotFound();
            }

            return View(clsEmployee);
        }

        // GET: EmployeesPortal/Create
        // GET: Employees/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("EmpID,FirstName,LastName,Password,CellNumber,Email")] ClsEmployee clsEmployee)
        {
            if (ModelState.IsValid)
            {
                _employeeRepository.Add(clsEmployee);
              
                return RedirectToAction(nameof(Index));
            }
            return View(clsEmployee);
        }

        // GET: Employees/Edit/5
        public IActionResult Edit(int id)
        {
            if (id < 0)
            {
                return NotFound();
            }


            var clsEmployee = _employeeRepository.GetEmployeeByID(id);

            if (clsEmployee == null)
            {
                return NotFound();
            }
            return View(clsEmployee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("EmpID,FirstName,LastName,Password,CellNumber,Email")] ClsEmployee clsEmployee)
        {
            if (id != clsEmployee.EmpID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _employeeRepository.Update(clsEmployee);

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClsEmployeeExists(clsEmployee.EmpID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(clsEmployee);
        }

        // GET: Employees/Delete/5
        public IActionResult Delete(int id)
        {
            if (id < 0)
            {
                return NotFound();
            }


            var clsEmployee = _employeeRepository.GetEmployeeByID(id);



            if (clsEmployee == null)
            {
                return NotFound();
            }




            return View(clsEmployee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var clsEmployee = _employeeRepository.GetEmployeeByID(id);
            _employeeRepository.Delete(id);


            return RedirectToAction(nameof(Index));
        }

        private bool ClsEmployeeExists(int id)
        {
            // return _context.CoreEmployees.Any(e => e.EmpID == id);
            return false;
        }
    }
}
