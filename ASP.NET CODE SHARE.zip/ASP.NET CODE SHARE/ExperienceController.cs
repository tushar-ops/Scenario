﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFCoreRepositoryPatternDemo.Models;

namespace EFCoreRepositoryPatternDemo.Controllers
{
    public class ExperienceController : Controller
    {
        //private readonly AppDBContext _context;
        private readonly IEmployeeRepository _employeeRepository;

        public ExperienceController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        // GET: ExperienceController
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login(ClsEmployee employee)
        {
            ClsEmployee Employee = _employeeRepository.GetEmployee(employee);
            if (Employee != null)
            {
                ViewBag.EmpID = Employee.EmpID;
                ViewBag.FirstName = Employee.FirstName;
                ViewBag.LastName = Employee.LastName;
                ViewBag.CellNumber = Employee.CellNumber;
                ViewBag.Email = Employee.Email;
                var model = _employeeRepository.GetAllSkill(Employee.EmpID);
                return View("Details",model);

               
            }
            else
            {
                return View();
            }
           
        }


        // GET: ExperienceController/Details/5
        public ActionResult Details(IEnumerable<ClsSkill> skills)
        {
            return View(skills);
        }

        // GET: ExperienceController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ExperienceController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ExperienceController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ExperienceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ExperienceController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ExperienceController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
